import { useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { Button, Container, Dropdown, Navbar, Offcanvas } from "react-bootstrap";
import "./Navbar.css";
import {
  IconFileSpreadsheet,
  IconFileText,
  IconHome,
  IconLogout,
  IconShieldCog,
  IconUser,
  IconUsers,
} from "@tabler/icons-react";
import Logo from "../../assets/images/logo5.png";
import { useAuth } from "../../context/AuthContext";

const baseNavItems = [
  { to: "/", label: "Home", icon: IconHome, end: true },
  { to: "/customer", label: "Customers", icon: IconUsers },
  { to: "/lite-bill", label: "Bills", icon: IconFileText },
  {
    to: "/upload-bill-from-excel",
    label: "Upload Excel",
    icon: IconFileSpreadsheet,
  },
];

const getInitials = (name) => {
  if (!name) return "?";
  return name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");
};

const apiOrigin = (import.meta.env.VITE_APP_API_URL || "").replace(/\/api\/?$/, "");

const NavigationBar = () => {
  const [expanded, setExpanded] = useState(false);
  const { user, isAuthenticated, isAdmin, logout } = useAuth();
  const navigate = useNavigate();

  const closeNav = () => setExpanded(false);

  const navItems = isAdmin
    ? [...baseNavItems, { to: "/users", label: "Users", icon: IconShieldCog }]
    : baseNavItems;

  const handleLogout = async () => {
    closeNav();
    await logout();
    navigate("/login", { replace: true });
  };

  const avatarSrc = user?.avatar ? `${apiOrigin}${user.avatar}` : null;

  return (
    <Navbar
      expand="lg"
      expanded={expanded}
      onToggle={setExpanded}
      className="app-navbar"
      sticky="top"
    >
      <Container fluid className="app-navbar-container">
        <Navbar.Brand
          as={Link}
          to={isAuthenticated ? "/" : "/login"}
          className="app-navbar-brand"
          onClick={closeNav}
        >
          <span className="app-navbar-logo-wrap">
            <img src={Logo} alt="Logo" className="app-navbar-logo" />
          </span>
          <span className="app-navbar-title d-none d-sm-inline">
            Bill Generating System
          </span>
        </Navbar.Brand>

        {isAuthenticated ? (
          <>
            <div className="app-navbar-mobile-actions d-lg-none">
              <Navbar.Toggle
                aria-label="Open navigation menu"
                aria-controls="main-nav-offcanvas"
              />
            </div>

            <Navbar.Offcanvas
              id="main-nav-offcanvas"
              aria-labelledby="main-nav-offcanvas-label"
              placement="end"
              className="app-navbar-offcanvas"
            >
              <Offcanvas.Header closeButton>
                <Offcanvas.Title id="main-nav-offcanvas-label">
                  <img src={Logo} alt="Logo" className="app-navbar-logo" />
                  <span>Bill Generating System</span>
                </Offcanvas.Title>
              </Offcanvas.Header>
              <Offcanvas.Body>
                <nav className="app-navbar-nav">
                  {navItems.map(({ to, label, icon: Icon, end }) => (
                    <NavLink
                      key={to}
                      to={to}
                      end={end}
                      onClick={closeNav}
                      className={({ isActive }) =>
                        `app-nav-link${isActive ? " active" : ""}`
                      }
                    >
                      <Icon size={20} stroke={1.75} />
                      <span>{label}</span>
                    </NavLink>
                  ))}
                </nav>

                <div className="app-navbar-profile d-none d-lg-flex">
                  <Dropdown align="end">
                    <Dropdown.Toggle as="button" className="user-menu-toggle" id="user-menu-toggle">
                      <span className="avatar-circle">
                        {avatarSrc ? <img src={avatarSrc} alt={user?.name} /> : getInitials(user?.name)}
                      </span>
                      <span className="user-menu-name">{user?.name}</span>
                    </Dropdown.Toggle>
                    <Dropdown.Menu>
                      <Dropdown.Item as={Link} to="/profile" onClick={closeNav}>
                        <IconUser size={16} stroke={1.75} className="me-2" />
                        Profile
                      </Dropdown.Item>
                      <Dropdown.Divider />
                      <Dropdown.Item onClick={handleLogout}>
                        <IconLogout size={16} stroke={1.75} className="me-2" />
                        Logout
                      </Dropdown.Item>
                    </Dropdown.Menu>
                  </Dropdown>
                </div>

                <div className="app-navbar-mobile-user d-lg-none">
                  <Link
                    to="/profile"
                    className="user-menu-toggle"
                    onClick={closeNav}
                  >
                    <span className="avatar-circle">
                      {avatarSrc ? <img src={avatarSrc} alt={user?.name} /> : getInitials(user?.name)}
                    </span>
                    <span className="user-menu-name">{user?.name}</span>
                  </Link>
                  <Button variant="outline-danger" size="sm" onClick={handleLogout}>
                    <IconLogout size={16} stroke={1.75} className="me-2" />
                    Logout
                  </Button>
                </div>
              </Offcanvas.Body>
            </Navbar.Offcanvas>
          </>
        ) : (
          <div className="app-navbar-guest-actions">
            <Button as={Link} to="/login" variant="outline-dark" size="sm">
              Login
            </Button>
            <Button as={Link} to="/register" variant="dark" size="sm">
              Register
            </Button>
          </div>
        )}
      </Container>
    </Navbar>
  );
};

export default NavigationBar;
