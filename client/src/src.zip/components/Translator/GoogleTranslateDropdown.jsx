import { useEffect } from "react";

const GoogleTranslateDropdown = () => {
  useEffect(() => {
    // Load Google Translate script dynamically if not already loaded
    const addGoogleTranslateScript = () => {
      const script = document.createElement("script");
      script.type = "text/javascript";
      script.src =
        "//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
      document.body.appendChild(script);
    };

    if (!window.google || !window.google.translate) {
      addGoogleTranslateScript();
    }

    window.googleTranslateElementInit = () => {
      new window.google.translate.TranslateElement(
        {
          pageLanguage: "en",
          includedLanguages: "en,gu,hi",
          layout: window.google.translate.TranslateElement.InlineLayout.SIMPLE,
        },
        "google_translate_element"
      );
    };
  }, []);

  // Function to change language to Gujarati programmatically
  const changeToGujarati = () => {
    const iframe = document.querySelector("iframe.skiptranslate");
    if (iframe) {
      const gujaratiOption = iframe.contentWindow.document.querySelector(
        'span.text:contains("Gujarati")'
      );
      if (gujaratiOption) {
        gujaratiOption.click();
      }
    }
  };

  return (
    <div className="d-flex align-items-center gap-2 flex-wrap mb-3">
      <div id="google_translate_element"></div>
      <button
        type="button"
        className="btn btn-outline-dark btn-sm"
        onClick={changeToGujarati}
      >
        Translate to Gujarati
      </button>
    </div>
  );
};

export default GoogleTranslateDropdown;
