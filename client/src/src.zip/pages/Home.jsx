/* eslint-disable react/prop-types */
import { Container } from "react-bootstrap";
import { IconReceipt2 } from "@tabler/icons-react";
import InputBoxes from "../components/Common/InputBoxes/InputBoxes";
import GoogleTranslateDropdown from "../components/Translator/GoogleTranslateDropdown";
import { useAuth } from "../context/AuthContext";

const Home = ({ setShowLoader }) => {
  const { user } = useAuth();

  return (
    <Container className="app-container">
      <GoogleTranslateDropdown />

      <div className="page-hero">
        <div className="page-hero-icon">
          <IconReceipt2 size={28} stroke={1.75} />
        </div>
        <div>
          <p className="page-hero-eyebrow">
            Welcome back{user?.name ? `, ${user.name.split(" ")[0]}` : ""} 👋
          </p>
          <h1 className="page-hero-title">Bill Generating System</h1>
          <p className="page-hero-subtitle">
            Manage your customers and bills efficiently.
          </p>
        </div>
      </div>

      <InputBoxes setShowLoader={setShowLoader} />
    </Container>
  );
};

export default Home;
